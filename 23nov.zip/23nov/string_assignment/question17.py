"""
17. Sort a string lexicographically.
"""
def sort_string(string):
    return ''.join(sorted(string))

print(sort_string("hello"))