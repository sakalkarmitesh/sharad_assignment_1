"""
13. Display input in upper and lower cases.
"""
def display_cases():
    user_input = input("Enter a string: ")
    print(user_input.upper())
    print(user_input.lower())

display_cases()